const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const session = require('express-session');
const { calShippingCost } = require('./models/feeCalculate');

const app = express();
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
    secret: 'warehouse_group8_key',
    resave: false,
    saveUninitialized: false
}));

const mongourl = 'mongodb+srv://batman:yym20051128@cluster0.q7yizvd.mongodb.net/?retryWrites=true&w=majority';
const dbName = 'warehouse_system';
const client = new MongoClient(mongourl);


async function getDB() {
    await client.connect();
    return client.db(dbName);
}

const checkLogin = (req, res, next) => {
    if (req.session && req.session.user) {
        return next();
    }
    res.redirect('/login');
};

app.get('/', (req, res) => {
    res.redirect(req.session && req.session.user ? '/parcels' : '/login');
});

app.get('/login', (req, res) => {
    res.render('login', { error: null, success: null });
});

app.post('/login', async (req, res) => {
    try {
        const db = await getDB();
        const { username, password } = req.body;
        const user = await db.collection('users').findOne({ username, password });
        if (!user) {
            return res.status(401).render('login', { error: 'Wrong username or password.', success: null });
        }
        req.session.user = { username: user.username };
        res.redirect('/parcels');
    } catch (err) {
        console.log(err);
        res.status(500).render('login', { error: 'Login failed.', success: null });
    }
});

app.get('/register', (req, res) => {
    res.render('register', { error: null });
});

app.post('/register', async (req, res) => {
    try {
        const db = await getDB();
        const { username, password } = req.body;
        const found = await db.collection('users').findOne({ username });
        if (found) {
            return res.status(400).render('register', { error: 'User already exists.' });
        }
        await db.collection('users').insertOne({
            username,
            password,
            createdAt: new Date().toLocaleString()
        });
        res.render('login', { error: null, success: 'Account created, please login.' });
    } catch (err) {
        console.log(err);
        res.status(500).render('register', { error: 'Register failed.' });
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/login');
    });
});

app.get('/parcels', checkLogin, async (req, res) => {
    try {
        const db = await getDB();
        let query = {};
        if (req.query.search) {
            query.$or = [
                { itemName: { $regex: req.query.search, $options: 'i' } },
                { senderAddress: { $regex: req.query.search, $options: 'i' } },
                { receiverAddress: { $regex: req.query.search, $options: 'i' } }
            ];
        }
        if (req.query.itemType && req.query.itemType !== 'All') {
            query.itemType = req.query.itemType;
        }
        const parcels = await db.collection('parcels').find(query).toArray();
        res.render('list', {
            user: req.session.user,
            parcels,
            search: req.query.search || '',
            selectedType: req.query.itemType || 'All'
        });
    } catch (err) {
        console.log(err);
        res.status(500).send('Failed to load parcels.');
    }
});

app.post('/create', checkLogin, async (req, res) => {
    try {
        const w = parseFloat(req.body.weight);
        if (isNaN(w) || w <= 0) {
            return res.status(400).send('Invalid weight.');
        }
        const db = await getDB();
        await db.collection('parcels').insertOne({
            itemType: req.body.itemType,
            itemName: req.body.itemName,
            senderAddress: req.body.senderAddress,
            receiverAddress: req.body.receiverAddress,
            weight: w,
            shippingFee: calShippingCost(w),
            createdAt: new Date().toLocaleString()
        });
        res.redirect('/parcels');
    } catch (err) {
        console.log(err);
        res.status(500).send('Create failed.');
    }
});

app.get('/edit', checkLogin, async (req, res) => {
    try {
        const db = await getDB();
        const parcel = await db.collection('parcels').findOne({
            _id: ObjectId.createFromHexString(req.query.id)
        });
        if (!parcel) return res.status(404).send('Not found.');
        res.render('edit', { parcel });
    } catch (err) {
        console.log(err);
        res.status(500).send('Error loading edit page.');
    }
});

app.post('/update', checkLogin, async (req, res) => {
    try {
        const w = parseFloat(req.body.weight);
        if (isNaN(w) || w <= 0) {
            return res.status(400).send('Invalid weight.');
        }
        const db = await getDB();
        await db.collection('parcels').updateOne(
            { _id: ObjectId.createFromHexString(req.body.id) },
            {
                $set: {
                    itemType: req.body.itemType,
                    itemName: req.body.itemName,
                    senderAddress: req.body.senderAddress,
                    receiverAddress: req.body.receiverAddress,
                    weight: w,
                    shippingFee: calShippingCost(w)
                }
            }
        );
        res.redirect('/parcels');
    } catch (err) {
        console.log(err);
        res.status(500).send('Update failed.');
    }
});

app.get('/delete', checkLogin, async (req, res) => {
    try {
        const db = await getDB();
        await db.collection('parcels').deleteOne({
            _id: ObjectId.createFromHexString(req.query.id)
        });
        res.redirect('/parcels');
    } catch (err) {
        console.log(err);
        res.status(500).send('Delete failed.');
    }
});

app.get('/api/parcels', async (req, res) => {
    try {
        const db = await getDB();
        const filter = req.query.itemName ? { itemName: { $regex: req.query.itemName, $options: 'i' } } : {};
        const data = await db.collection('parcels').find(filter).toArray();
        res.status(200).json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/parcels', async (req, res) => {
    try {
        const w = parseFloat(req.body.weight);
        if (isNaN(w) || w <= 0) {
            return res.status(400).json({ error: 'Weight must be > 0' });
        }
        const db = await getDB();
        const doc = {
            itemType: req.body.itemType || 'Daily necessities',
            itemName: req.body.itemName,
            senderAddress: req.body.senderAddress,
            receiverAddress: req.body.receiverAddress,
            weight: w,
            shippingFee: calShippingCost(w),
            createdAt: new Date().toLocaleString()
        };
        const result = await db.collection('parcels').insertOne(doc);
        res.status(201).json({ id: result.insertedId, parcel: doc });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/parcels/:itemName', async (req, res) => {
    try {
        const w = parseFloat(req.body.weight);
        if (isNaN(w) || w <= 0) {
            return res.status(400).json({ error: 'Weight must be > 0' });
        }
        const db = await getDB();
        const updates = {
            itemType: req.body.itemType || 'Daily necessities',
            senderAddress: req.body.senderAddress,
            receiverAddress: req.body.receiverAddress,
            weight: w,
            shippingFee: calShippingCost(w)
        };
        const result = await db.collection('parcels').updateOne(
            { itemName: req.params.itemName },
            { $set: updates }
        );
        res.status(200).json({ modified: result.modifiedCount, data: updates });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/parcels/:itemName', async (req, res) => {
    try {
        const db = await getDB();
        const result = await db.collection('parcels').deleteOne({ itemName: req.params.itemName });
        res.status(200).json({ deleted: result.deletedCount });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

const port = process.env.PORT || 8099;
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
