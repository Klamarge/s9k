const express = require('express');
const { MongoClient, ServerApiVersion, ObjectId } = require('mongodb');
const formidable = require('express-formidable');
const session = require('express-session');
const { calShippingCost } = require('./management/feeCalculate');

const app = express();
app.set('view engine', 'ejs');
app.use(formidable());

// Session middleware for authentication
app.use(session({
    secret: 'group8_warehouse_secret_2026',
    resave: false,
    saveUninitialized: false
}));

// MongoDB Atlas connection string
const mongourl = 'mongodb+srv://batman:yym20051128@cluster0.q7yizvd.mongodb.net/?retryWrites=true&w=majority';
const dbName = 'warehouse_system';
const userCollection = 'users';
const parcelCollection = 'parcels';

const client = new MongoClient(mongourl, {
    serverApi: {
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true,
    }
});

// Authentication middleware to protect CRUD routes
const requireLogin = (req, res, next) => {
    if (req.session && req.session.user) {
        return next();
    }
    res.redirect('/login');
};

// ================= AUTHENTICATION ROUTES =================

app.get('/', (req, res) => {
    if (req.session && req.session.user) {
        return res.redirect('/parcels');
    }
    res.redirect('/login');
});

app.get('/login', (req, res) => {
    res.status(200).render('login', { error: null, success: null });
});

app.post('/login', async (req, res) => {
    try {
        await client.connect();
        const db = client.db(dbName);
        const { username, password } = req.fields;
        const user = await db.collection(userCollection).findOne({ username, password });
        if (user) {
            req.session.user = { username: user.username };
            return res.redirect('/parcels');
        }
        res.status(401).render('login', { error: 'Invalid username or password.', success: null });
    } catch (err) {
        console.error(err);
        res.status(500).render('login', { error: 'Server error during login.', success: null });
    }
});

app.get('/register', (req, res) => {
    res.status(200).render('register', { error: null });
});

app.post('/register', async (req, res) => {
    try {
        await client.connect();
        const db = client.db(dbName);
        const { username, password } = req.fields;
        const existing = await db.collection(userCollection).findOne({ username });
        if (existing) {
            return res.status(400).render('register', { error: 'Username already exists.' });
        }
        await db.collection(userCollection).insertOne({
            username,
            password,
            createdAt: new Date().toLocaleString()
        });
        res.status(200).render('login', { error: null, success: 'Registration successful! Please login.' });
    } catch (err) {
        console.error(err);
        res.status(500).render('register', { error: 'Server error during registration.' });
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/login');
    });
});

// ================= WEB CRUD ROUTES (PROTECTED) =================

// READ & SEARCH (supports searching by itemType, itemName, or receiverAddress)
app.get('/parcels', requireLogin, async (req, res) => {
    try {
        await client.connect();
        const db = client.db(dbName);
        let filter = {};
        if (req.query.search) {
            filter = {
                $or: [
                    { itemType: { $regex: req.query.search, $options: 'i' } },
                    { itemName: { $regex: req.query.search, $options: 'i' } },
                    { receiverAddress: { $regex: req.query.search, $options: 'i' } }
                ]
            };
        }
        const parcels = await db.collection(parcelCollection).find(filter).toArray();
        res.status(200).render('list', {
            user: req.session.user,
            parcels,
            search: req.query.search || ''
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Error loading parcels list.');
    }
});

// CREATE (directly submitted from the top row of list.ejs)
app.post('/create', requireLogin, async (req, res) => {
    try {
        const weightVal = parseFloat(req.fields.weight);
        if (isNaN(weightVal) || weightVal <= 0) {
            return res.status(400).send('Weight must be a valid number greater than 0.');
        }

        await client.connect();
        const db = client.db(dbName);
        const fee = calShippingCost(weightVal);

        await db.collection(parcelCollection).insertOne({
            itemType: req.fields.itemType,
            itemName: req.fields.itemName,
            senderAddress: req.fields.senderAddress,
            receiverAddress: req.fields.receiverAddress,
            weight: weightVal,
            shippingFee: fee,
            createdAt: new Date().toLocaleString()
        });
        res.redirect('/parcels');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error creating parcel.');
    }
});

// UPDATE (render edit page & save updated item with recalculated shipping fee)
app.get('/edit', requireLogin, async (req, res) => {
    try {
        await client.connect();
        const db = client.db(dbName);
        const parcel = await db.collection(parcelCollection).findOne({
            _id: ObjectId.createFromHexString(req.query.id)
        });
        if (!parcel) return res.status(404).send('Parcel not found.');
        res.status(200).render('edit', { parcel });
    } catch (err) {
        console.error(err);
        res.status(500).send('Error loading edit page.');
    }
});

app.post('/update', requireLogin, async (req, res) => {
    try {
        const weightVal = parseFloat(req.fields.weight);
        if (isNaN(weightVal) || weightVal <= 0) {
            return res.status(400).send('Weight must be a valid number greater than 0.');
        }

        await client.connect();
        const db = client.db(dbName);
        const fee = calShippingCost(weightVal);

        await db.collection(parcelCollection).updateOne(
            { _id: ObjectId.createFromHexString(req.fields.id) },
            {
                $set: {
                    itemType: req.fields.itemType,
                    itemName: req.fields.itemName,
                    senderAddress: req.fields.senderAddress,
                    receiverAddress: req.fields.receiverAddress,
                    weight: weightVal,
                    shippingFee: fee
                }
            }
        );
        res.redirect('/parcels');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error updating parcel.');
    }
});

// DELETE
app.get('/delete', requireLogin, async (req, res) => {
    try {
        await client.connect();
        const db = client.db(dbName);
        await db.collection(parcelCollection).deleteOne({
            _id: ObjectId.createFromHexString(req.query.id)
        });
        res.redirect('/parcels');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error deleting parcel.');
    }
});

// ================= RESTFUL API ROUTES (NO LOGIN REQUIRED) =================

// 1. GET all or search by itemName
app.get('/api/parcels', async (req, res) => {
    try {
        await client.connect();
        const db = client.db(dbName);
        const filter = req.query.itemName ? { itemName: { $regex: req.query.itemName, $options: 'i' } } : {};
        const parcels = await db.collection(parcelCollection).find(filter).toArray();
        res.status(200).json(parcels);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 2. POST create new parcel via API
app.post('/api/parcels', async (req, res) => {
    try {
        const weightVal = parseFloat(req.fields.weight);
        if (isNaN(weightVal) || weightVal <= 0) {
            return res.status(400).json({ error: 'Weight must be greater than 0' });
        }
        await client.connect();
        const db = client.db(dbName);
        const newParcel = {
            itemType: req.fields.itemType || 'Daily necessities',
            itemName: req.fields.itemName,
            senderAddress: req.fields.senderAddress,
            receiverAddress: req.fields.receiverAddress,
            weight: weightVal,
            shippingFee: calShippingCost(weightVal),
            createdAt: new Date().toLocaleString()
        };
        const result = await db.collection(parcelCollection).insertOne(newParcel);
        res.status(201).json({ message: 'Parcel created', insertedId: result.insertedId, parcel: newParcel });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 3. PUT update parcel by itemName via API
app.put('/api/parcels/:itemName', async (req, res) => {
    try {
        const weightVal = parseFloat(req.fields.weight);
        if (isNaN(weightVal) || weightVal <= 0) {
            return res.status(400).json({ error: 'Weight must be greater than 0' });
        }
        await client.connect();
        const db = client.db(dbName);
        const updateFields = {
            itemType: req.fields.itemType || 'Daily necessities',
            senderAddress: req.fields.senderAddress,
            receiverAddress: req.fields.receiverAddress,
            weight: weightVal,
            shippingFee: calShippingCost(weightVal)
        };
        const result = await db.collection(parcelCollection).updateOne(
            { itemName: req.params.itemName },
            { $set: updateFields }
        );
        res.status(200).json({ message: 'Parcel updated', modifiedCount: result.modifiedCount, updatedData: updateFields });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 4. DELETE parcel by itemName via API
app.delete('/api/parcels/:itemName', async (req, res) => {
    try {
        await client.connect();
        const db = client.db(dbName);
        const result = await db.collection(parcelCollection).deleteOne({ itemName: req.params.itemName });
        res.status(200).json({ message: 'Parcel deleted', deletedCount: result.deletedCount });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

const port = process.env.PORT || 8099;
app.listen(port, () => {
    console.log(`Warehouse Logistics System running at http://localhost:${port}`);
});
