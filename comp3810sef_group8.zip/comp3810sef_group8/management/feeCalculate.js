function calShippingCost(weightInput) {
    const weight = parseFloat(weightInput);
    if (isNaN(weight) || weight <= 0) {
        return 0;
    }
   
    if (weight <= 1) {
        return 15;
    }
    const extraWeight = Math.ceil(weight - 1);
    return 15 + extraWeight * 5;
}

module.exports = { calShippingCost };


